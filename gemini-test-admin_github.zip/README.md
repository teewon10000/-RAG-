# RAG Admin App (CLI Version)

이 프로젝트는 RAG(Retrieval-Augmented Generation) 지식 기반을 관리하기 위한 애플리케이션입니다. 문서를 업로드하고, 청크를 생성하며, 벡터 데이터베이스를 업데이트하는 기능을 제공합니다.

## 🚀 실행 방법

이 앱은 명령 프롬프트(CMD) 또는 PowerShell에서 직접 실행해야 합니다.

자세한 실행 방법은 `how_to_run_admin_app_cli.txt` 파일을 참조하세요.

### 요약:

1.  **프로젝트 다운로드:**
    GitHub에서 이 프로젝트를 다운로드하거나 클론합니다.

2.  **프로젝트 폴더로 이동:**
    터미널에서 프로젝트의 루트 폴더로 이동합니다.
    `cd [프로젝트_폴더_경로]`

3.  **가상환경 설정 및 라이브러리 설치 (최초 1회):**
    ```powershell
    python -m venv venv
    .\venv\Scripts\activate
    pip install -r requirements.txt
    ```

4.  **백엔드 서버 실행 (새 터미널 1):**
    ```powershell
    cd [프로젝트_폴더_경로]
    .\venv\Scripts\activate
    uvicorn rag_admin_app.main:app --host 0.0.0.0 --port 8001
    ```

5.  **프론트엔드 UI 실행 (새 터미널 2):**
    ```powershell
    cd [프로젝트_폴더_경로]
    .\venv\Scripts\activate
    streamlit run rag_admin_app\streamlit_app.py --server.port 8502
    ```

6.  **웹 브라우저 접속:**
    `http://localhost:8502` 로 접속하여 앱을 사용합니다.

## ⚙️ 설정

앱의 데이터 경로는 `config.json` 파일에 설정되어 있습니다. 이 파일은 앱이 실행되는 폴더를 기준으로 상대 경로를 사용합니다.

*   `data_path`: 원본 문서 파일이 저장될 폴더 (`./data`)
*   `chunks_path`: 문서 청크 파일이 저장될 폴더 (`./chunks`)
*   `chroma_db_path`: 벡터 데이터베이스가 저장될 폴더 (`./chroma_db`)

이 폴더들은 앱 실행 시 자동으로 생성됩니다. 필요에 따라 `config.json` 파일을 직접 수정하여 경로를 변경할 수 있습니다.

## 📂 폴더 구조

```
[프로젝트 루트 폴더]
├── rag_admin_app/
│   ├── main.py
│   ├── rag_processor.py
│   └── streamlit_app.py
├── data/           (원본 문서 저장 폴더)
├── chunks/         (문서 청크 저장 폴더)
├── chroma_db/      (벡터 DB 저장 폴더)
├── config.json     (앱 설정 파일)
├── .gitignore      (Git 무시 파일)
├── how_to_run_admin_app_cli.txt (CLI 실행 상세 매뉴얼)
└── README.md       (프로젝트 설명 및 요약된 실행 방법)
```

## 🛠️ 개발 환경 (참고용)

이 앱은 Python 3.10 환경에서 FastAPI, Streamlit, LangChain, ChromaDB 등을 사용하여 개발되었습니다.

## 🤝 기여

버그 보고, 기능 제안 등 모든 기여를 환영합니다.
