import os
import shutil
from langchain_community.vectorstores import Chroma
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import UnstructuredFileLoader, TextLoader
from langchain_ollama import OllamaEmbeddings
from langchain.schema import Document

def generate_chunks_from_documents(documents_directory: str, chunks_directory: str):
    try:
        if not os.path.exists(chunks_directory):
            os.makedirs(chunks_directory)

        text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
        new_chunks_count = 0
        skipped_count = 0

        if not os.path.exists(documents_directory):
            print(f"경고: 문서 디렉토리 '{documents_directory}'를 찾을 수 없습니다.")
            return 0, 0

        for root, _, files in os.walk(documents_directory):
            for filename in files:
                doc_file_path = os.path.join(root, filename)
                relative_path = os.path.relpath(root, documents_directory)
                chunk_subfolder = os.path.join(chunks_directory, relative_path) if relative_path != '.' else chunks_directory
                chunk_filename = f"{os.path.splitext(filename)[0]}_chunks.txt"
                chunk_filepath = os.path.join(chunk_subfolder, chunk_filename)

                if os.path.exists(chunk_filepath):
                    skipped_count += 1
                    continue

                if not os.path.exists(chunk_subfolder):
                    os.makedirs(chunk_subfolder)

                try:
                    loader = UnstructuredFileLoader(doc_file_path)
                    documents = loader.load()
                    splits = text_splitter.split_documents(documents)

                    if not splits:
                        continue

                    with open(chunk_filepath, "w", encoding="utf-8") as f:
                        f.write(splits[0].page_content)
                        for i, split in enumerate(splits[1:], start=2):
                            f.write(f"\n\n--- chunk {i} ---\n\n")
                            f.write(split.page_content)
                    new_chunks_count += 1
                except Exception as e:
                    print(f"오류: '{filename}' 처리 중 - {e}")
                    continue
        
        return new_chunks_count, skipped_count
    except Exception as e:
        import traceback
        traceback.print_exc()
        return 0, 0

def update_db_from_chunk_files(chunks_directory: str, db_directory: str, model_name: str):
    try:
        oembed = OllamaEmbeddings(model=model_name)

        if os.path.exists(db_directory):
            shutil.rmtree(db_directory)
        os.makedirs(db_directory)

        if not os.path.exists(chunks_directory):
            print(f"경고: 청크 디렉토리 '{chunks_directory}'를 찾을 수 없습니다.")
            return None

        all_docs = []
        for root, _, files in os.walk(chunks_directory):
            for filename in files:
                if filename.endswith("_chunks.txt"):
                    file_path = os.path.join(root, filename)
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()
                    
                    chunks = content.split("\n\n--- chunk ")
                    first_chunk_content = chunks[0]
                    all_docs.append(Document(page_content=first_chunk_content, metadata={"source": filename, "chunk": 1}))

                    for chunk in chunks[1:]:
                        try:
                            chunk_num_str, chunk_content = chunk.split(" ---\n\n", 1)
                            all_docs.append(Document(page_content=chunk_content, metadata={"source": filename, "chunk": int(chunk_num_str)}))
                        except ValueError:
                            continue

        if not all_docs:
            return None

        vectorstore = Chroma.from_documents(documents=all_docs, embedding=oembed, persist_directory=db_directory)
        vectorstore.persist()
        return True
    except Exception as e:
        import traceback
        traceback.print_exc()
        return False

def get_document_chunks(file_path: str):
    try:
        loader = UnstructuredFileLoader(file_path)
        documents = loader.load()
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=100)
        splits = text_splitter.split_documents(documents)
        return [s.page_content for s in splits]
    except Exception as e:
        return None