import os
import shutil
import sys
import json
from fastapi import FastAPI, UploadFile, File, HTTPException

# --- 설정 관리 ---
# 이 파일(main.py)의 위치를 기준으로 config.json 경로를 설정합니다.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.abspath(os.path.join(BASE_DIR, '..', 'config.json'))

# 모듈 검색 경로에 현재 디렉토리 추가
sys.path.append(str(BASE_DIR))

def load_config():
    """config.json 파일에서 경로 설정을 불러옵니다."""
    if not os.path.exists(CONFIG_PATH):
        raise HTTPException(status_code=500, detail="설정 파일(config.json)을 찾을 수 없습니다.")
    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)

# --- 환경 변수 설정 (Ollama) ---
os.environ['OLLAMA_HOST'] = 'http://localhost:11434'
# OLLAMA_MODELS는 필요 시 설정 (보통 기본 경로를 사용)

# rag_processor는 설정 로드 후에 import 합니다.
from rag_processor import (
    generate_chunks_from_documents,
    update_db_from_chunk_files,
    get_document_chunks
)

app = FastAPI()
active_model_name = "llama3:8b"

@app.post("/upload_document")
async def upload_document(file: UploadFile = File(...)):
    config = load_config()
    document_dir = config['data_path']
    if not os.path.exists(document_dir):
        os.makedirs(document_dir)

    file_location = os.path.join(document_dir, file.filename)
    allowed_extensions = {'.pdf', '.xlsx', '.pptx', '.docx', '.txt'}
    if os.path.splitext(file.filename)[1].lower() not in allowed_extensions:
        raise HTTPException(status_code=400, detail="지원하지 않는 파일 형식입니다.")

    try:
        with open(file_location, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"파일 저장 중 오류 발생: {e}")

    return {"message": f"문서 '{file.filename}'가 성공적으로 업로드되었습니다."}

@app.post("/generate_chunks")
def generate_chunks():
    config = load_config()
    try:
        new_count, skipped_count = generate_chunks_from_documents(config['data_path'], config['chunks_path'])
        return {"message": f"청크 생성 완료. 신규: {new_count}개, 기존: {skipped_count}개"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"청크 생성 중 오류: {e}")

@app.post("/update_rag_knowledge")
def update_rag_knowledge():
    config = load_config()
    try:
        success = update_db_from_chunk_files(config['chunks_path'], config['chroma_db_path'], active_model_name)
        if not success:
            raise HTTPException(status_code=500, detail="지식 기반 업데이트 실패")
        return {"message": "수정된 청크로 지식 기반을 성공적으로 업데이트했습니다."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"지식 기반 업데이트 중 오류: {e}")

@app.get("/list_documents")
async def list_documents():
    config = load_config()
    document_dir = config['data_path']
    try:
        if not os.path.exists(document_dir):
            return {"documents": []}
        files_list = []
        for root, _, files in os.walk(document_dir):
            for filename in files:
                full_path = os.path.join(root, filename)
                relative_path = os.path.relpath(full_path, document_dir)
                files_list.append({"name": relative_path.replace("\\", "/"), "path": full_path})
        return {"documents": files_list}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"문서 목록 로딩 중 오류: {e}")

@app.get("/get_document_chunks")
async def get_document_chunks_api(file_path: str):
    config = load_config()
    document_dir = config['data_path']
    # 보안 검사: 요청된 파일이 설정된 data_path 내에 있는지 확인
    if not os.path.abspath(file_path).startswith(os.path.abspath(document_dir)):
        raise HTTPException(status_code=403, detail="허용되지 않는 파일 경로입니다.")
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="파일을 찾을 수 없습니다.")

    chunks = get_document_chunks(file_path)
    if chunks is None:
        raise HTTPException(status_code=500, detail="문서에서 청크를 가져오지 못했습니다.")
    return {"chunks": chunks}

# 설정 API 추가
@app.get("/get_config")
async def get_config():
    return load_config()

@app.post("/save_config")
async def save_config(config_data: dict):
    try:
        with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
            json.dump(config_data, f, indent=2)
        return {"message": "설정이 성공적으로 저장되었습니다."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"설정 파일 저장 중 오류: {e}")

if __name__ == "__main__":
    print("독립 실행형 RAG Admin 백엔드 서버를 시작합니다...")
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)