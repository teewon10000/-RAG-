import streamlit as st
import requests
import json

# --- 기본 설정 ---
FASTAPI_BACKEND_URL = "http://localhost:8001"
st.set_page_config(layout="wide", page_title="RAG Admin")

# --- API 함수 ---
def get_config():
    try:
        return requests.get(f"{FASTAPI_BACKEND_URL}/get_config").json()
    except Exception:
        return None

def save_config(config_data):
    try:
        return requests.post(f"{FASTAPI_BACKEND_URL}/save_config", json=config_data)
    except Exception as e:
        st.error(f"설정 저장 실패: {e}")
        return None

# --- 세션 상태 초기화 ---
if 'config' not in st.session_state:
    st.session_state.config = get_config()

# --- UI 렌더링 ---
st.title("⚙️ RAG 지식 기반 관리자")

if not st.session_state.config:
    st.error("백엔드 서버에 연결할 수 없습니다. uvicorn 서버가 실행 중인지 확인하세요.")
else:
    # 탭 구성
    tab1, tab2, tab3 = st.tabs(["🗂️ 문서 및 청크 관리", "🔍 청크 미리보기", "🔧 경로 설정"])

    # --- 경로 설정 탭 ---
    with tab3:
        st.header("데이터 폴더 경로 설정")
        st.markdown("AI가 참조할 데이터, 청크, DB 폴더의 절대 경로를 지정합니다.")
        
        config = st.session_state.config
        data_path = st.text_input("원본 문서 폴더 (data_path)", value=config.get('data_path', ''))
        chunks_path = st.text_input("청크 파일 폴더 (chunks_path)", value=config.get('chunks_path', ''))
        db_path = st.text_input("벡터 DB 폴더 (chroma_db_path)", value=config.get('chroma_db_path', ''))

        if st.button("경로 저장"):
            new_config = {
                "data_path": data_path.replace("\\\\", "/"),
                "chunks_path": chunks_path.replace("\\\\", "/"),
                "chroma_db_path": db_path.replace("\\\\", "/")
            }
            response = save_config(new_config)
            if response and response.status_code == 200:
                st.session_state.config = new_config # 세션 상태 업데이트
                st.success("설정이 성공적으로 저장되었습니다!")
                st.rerun()
            else:
                st.error("설정 저장에 실패했습니다.")

    # --- 문서 및 청크 관리 탭 ---
    with tab1:
        st.header("워크플로우")
        st.markdown("**1. 문서 업로드 → 2. 새 문서 청크 생성 → 3. (필요시) 청크 파일 수정 → 4. 지식 기반 업데이트**")
        
        col1, col2 = st.columns(2)
        with col1:
            st.subheader("1. 문서 업로드")
            uploaded_file = st.file_uploader("문서를 `data` 폴더에 업로드", help="탐색기에서 직접 추가/정리하는 것을 권장합니다.")
            if uploaded_file:
                with st.spinner(f"'{uploaded_file.name}' 업로드 중..."):
                    requests.post(f"{FASTAPI_BACKEND_URL}/upload_document", files={"file": (uploaded_file.name, uploaded_file.getvalue())})
                    st.success(f"'{uploaded_file.name}' 업로드 완료!")

            st.subheader("현재 문서 목록")
            if st.button("새로고침"):
                st.session_state.docs = requests.get(f"{FASTAPI_BACKEND_URL}/list_documents").json()
            
            if 'docs' not in st.session_state:
                 st.session_state.docs = requests.get(f"{FASTAPI_BACKEND_URL}/list_documents").json()

            docs_data = st.session_state.docs.get("documents", [])
            st.write(f"총 {len(docs_data)}개의 문서")
            with st.expander("전체 문서 목록 보기"):
                for doc in sorted(docs_data, key=lambda x: x['name']):
                    st.markdown(f"- `{doc['name']}`")

        with col2:
            st.subheader("2. 새 문서 청크 생성")
            st.markdown("새로 추가된 문서만 처리합니다. 기존 청크는 보존됩니다.")
            if st.button("새 문서 청크 생성"):
                with st.spinner("새 문서를 찾아 청크 파일을 생성하는 중..."):
                    res = requests.post(f"{FASTAPI_BACKEND_URL}/generate_chunks").json()
                    st.success(res.get('message', "완료!"))

            st.subheader("4. 지식 기반 업데이트")
            st.markdown("`chunks` 폴더의 수정된 내용으로 DB를 새로 만듭니다.")
            if st.button("지식 기반 업데이트", type="primary"):
                with st.spinner("지식 기반을 업데이트하는 중... (Ollama 필요)"):
                    res = requests.post(f"{FASTAPI_BACKEND_URL}/update_rag_knowledge").json()
                    st.success(res.get('message', "완료!"))

    # --- 청크 미리보기 탭 ---
    with tab2:
        st.header("원본 문서 청크 미리보기")
        st.markdown("이 섹션은 원본 문서가 어떻게 청크로 나뉘는지 참고용으로 보여줍니다.")
        
        if docs_data:
            doc_names = [doc['name'] for doc in sorted(docs_data, key=lambda x: x['name'])]
            selected_doc_name = st.selectbox("미리 볼 문서를 선택하세요:", doc_names)

            if selected_doc_name:
                doc_path = next((d['path'] for d in docs_data if d['name'] == selected_doc_name), None)
                if st.button(f"'{selected_doc_name}' 청크 미리보기"):
                    with st.spinner("청크를 불러오는 중..."):
                        res = requests.get(f"{FASTAPI_BACKEND_URL}/get_document_chunks", params={"file_path": doc_path})
                        if res.status_code == 200:
                            st.session_state.preview_chunks = res.json().get("chunks", [])
                        else:
                            st.error(f"청크 로딩 실패: {res.text}")
                            st.session_state.preview_chunks = []
            
            if 'preview_chunks' in st.session_state and st.session_state.preview_chunks:
                st.write(f"총 {len(st.session_state.preview_chunks)}개의 청크")
                for i, chunk in enumerate(st.session_state.preview_chunks):
                    with st.expander(f"청크 {i+1}"):
                        st.text(chunk)
