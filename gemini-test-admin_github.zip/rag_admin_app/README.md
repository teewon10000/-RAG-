# RAG 문서 관리 애플리케이션

이 애플리케이션은 RAG(Retrieval-Augmented Generation) 시스템의 문서 관리 및 지식 기반 업데이트를 담당합니다. 사용자가 문서를 업로드하거나 기존 문서 폴더의 변경 사항을 지식 기반에 반영할 수 있습니다.

## 기능
*   다양한 형식의 문서 업로드 및 처리
*   문서 폴더의 모든 파일을 다시 로드하여 지식 기반 업데이트

## 실행 방법

1.  **백엔드 서버 실행**:
    새로운 명령 프롬프트/터미널을 열고 다음 명령어를 순서대로 실행합니다:
    ```bash
    cd C:\AI\gemini-test\rag_admin_app
    .\venv_new\Scripts\activate
    uvicorn main:app --host 0.0.0.0 --port 8001
    ```
    이 명령어는 문서 관리의 FastAPI 백엔드 서버를 `http://localhost:8001`에서 시작합니다.

2.  **프론트엔드 UI 실행**:
    또 다른 명령 프롬프트/터미널을 열고 다음 명령어를 순서대로 실행합니다:
    ```bash
    cd C:\AI\gemini-test
    rag_app\venv_new\Scripts\activate
    streamlit run rag_admin_app\streamlit_app.py
    ```
    이 명령어는 문서 관리의 Streamlit UI를 `http://localhost:8502`에서 시작합니다.

## 설정
*   **FastAPI 백엔드 URL**: `rag_admin_app/streamlit_app.py` 파일에서 `FASTAPI_BACKEND_URL` 변수를 통해 백엔드 서버의 주소를 설정할 수 있습니다. 기본값은 `http://localhost:8001`입니다.
*   **문서 경로**: `rag_admin_app/main.py` 파일에서 `DOCUMENT_DIR` 변수를 통해 문서가 저장되는 경로를 설정할 수 있습니다. 기본값은 `C:\AI\gemini-test\data`입니다.
*   **ChromaDB 경로**: `rag_admin_app/main.py` 파일에서 `CHROMA_DB_DIR` 변수를 통해 ChromaDB가 저장되는 경로를 설정할 수 있습니다. 기본값은 `C:\AI\gemini-test\chroma_db`입니다.
